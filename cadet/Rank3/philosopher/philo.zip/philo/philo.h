/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bperez-a <bperez-a@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 10:04:21 by bperez-a          #+#    #+#             */
/*   Updated: 2024/03/27 12:17:02 by bperez-a         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <pthread.h>
# include <stdio.h>
# include <stdlib.h>
# include <sys/time.h>
# include <unistd.h>

typedef struct s_program
{
	int						number_of_philosophers;
	int						time_to_die;
	int						time_to_eat;
	int						time_to_sleep;
	int						must_eat_count;
	int						end_condition;
	pthread_mutex_t			*forks_mutexes;
	pthread_mutex_t			control_mutex;
	struct s_philosopher	*philosophers;
	unsigned long			start_time;

}							t_program;

typedef struct s_philosopher
{
	int						id;
	pthread_t				thread;
	int						left_fork_id;
	int						right_fork_id;
	unsigned long			last_meal_time;
	int						meals_eaten;
	int						full;
	struct s_program		*program;
}							t_philosopher;

t_program					*init_program(int argc, char **argv);
int							start_philosophers(t_program *program);
void						*philosopher_routine(void *arg);
int							ft_atoi(const char *nptr);
unsigned long				get_time_in_ms(void);
void						log_action(t_philosopher *philo,
								const char *action);
void						log_death(t_philosopher *philo);
int							ft_strncmp(const char *s1, const char *s2,
								size_t n);
void						ft_usleep(int time);

#endif
