/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   routine.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bperez-a <bperez-a@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/19 19:08:23 by bperez-a          #+#    #+#             */
/*   Updated: 2024/03/27 12:06:52 by bperez-a         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	log_action(t_philosopher *philo, const char *action)
{
	unsigned long	time_in_ms;

	pthread_mutex_lock(&philo->program->control_mutex);
	if (!philo->program->end_condition || !ft_strncmp(action, "died", 4))
	{
		time_in_ms = get_time_in_ms() - philo->program->start_time;
		printf("%lu %d %s\n", time_in_ms, philo->id + 1, action);
	}
	pthread_mutex_unlock(&philo->program->control_mutex);
}

void	philo_eat(t_philosopher *philo)
{
	if (philo->program->number_of_philosophers == 1)
	{
		log_action(philo, "has taken a fork");
		ft_usleep(philo->program->time_to_die + 10);
	}
	pthread_mutex_lock(&philo->program->forks_mutexes[philo->left_fork_id]);
	log_action(philo, "has taken a fork");
	pthread_mutex_lock(&philo->program->forks_mutexes[philo->right_fork_id]);
	log_action(philo, "has taken a fork");
	log_action(philo, "is eating");
	philo->meals_eaten++;
	if (philo->meals_eaten == philo->program->must_eat_count)
		philo->full = 1;
	pthread_mutex_lock(&philo->program->control_mutex);
	philo->last_meal_time = get_time_in_ms();
	pthread_mutex_unlock(&philo->program->control_mutex);
	ft_usleep(philo->program->time_to_eat);
	pthread_mutex_unlock(&philo->program->forks_mutexes[philo->left_fork_id]);
	pthread_mutex_unlock(&philo->program->forks_mutexes[philo->right_fork_id]);
}

void	philo_sleep(t_philosopher *philo)
{
	log_action(philo, "is sleeping");
	ft_usleep(philo->program->time_to_sleep);
}

void	philo_think(t_philosopher *philo)
{
	log_action(philo, "is thinking");
}

void	*philosopher_routine(void *arg)
{
	t_philosopher	*philo;

	philo = (t_philosopher *)arg;
	usleep(1000);
	if (philo->id % 2)
		usleep(15000);
	while (1)
	{
		philo_eat(philo);
		philo_sleep(philo);
		philo_think(philo);
		pthread_mutex_lock(&philo->program->control_mutex);
		if (philo->program->end_condition)
		{
			pthread_mutex_unlock(&philo->program->control_mutex);
			break ;
		}
		pthread_mutex_unlock(&philo->program->control_mutex);
	}
	return (NULL);
}
