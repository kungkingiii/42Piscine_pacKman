/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bperez-a <bperez-a@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 10:25:47 by bperez-a          #+#    #+#             */
/*   Updated: 2024/03/27 12:16:53 by bperez-a         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	init_values(t_program *program, int argc, char **argv)
{
	program->number_of_philosophers = ft_atoi(argv[1]);
	program->time_to_die = ft_atoi(argv[2]);
	program->time_to_eat = ft_atoi(argv[3]);
	program->time_to_sleep = ft_atoi(argv[4]);
	if (argc == 6)
		program->must_eat_count = ft_atoi(argv[5]);
	else
		program->must_eat_count = -1;
	if (program->number_of_philosophers < 1 || program->time_to_die < 1
		|| program->time_to_eat < 1 || program->time_to_sleep < 1
		|| (program->must_eat_count < 0 && argc == 6))
	{
		free(program);
		return (0);
	}
	program->end_condition = 0;
	return (1);
}

int	init_mutexes(t_program *program)
{
	int	i;

	program->forks_mutexes = malloc(sizeof(pthread_mutex_t)
			* program->number_of_philosophers);
	if (program->forks_mutexes == NULL)
	{
		free(program);
		return (0);
	}
	i = 0;
	while (i < program->number_of_philosophers)
		pthread_mutex_init(&program->forks_mutexes[i++], NULL);
	pthread_mutex_init(&program->control_mutex, NULL);
	return (1);
}

int	init_philos(t_program *program)
{
	int	i;

	program->philosophers = malloc(sizeof(t_philosopher)
			* program->number_of_philosophers);
	if (program->philosophers == NULL)
	{
		free(program->forks_mutexes);
		free(program);
		return (0);
	}
	i = 0;
	while (i < program->number_of_philosophers)
	{
		program->philosophers[i].id = i;
		program->philosophers[i].left_fork_id = i;
		program->philosophers[i].right_fork_id = (i + 1)
			% program->number_of_philosophers;
		program->philosophers[i].last_meal_time = get_time_in_ms();
		program->philosophers[i].meals_eaten = 0;
		program->philosophers[i].full = 0;
		program->philosophers[i].program = program;
		i++;
	}
	return (1);
}

t_program	*init_program(int argc, char **argv)
{
	t_program	*program;

	program = malloc(sizeof(t_program));
	if (!program)
		return (NULL);
	if (!init_values(program, argc, argv))
		return (NULL);
	if (!init_mutexes(program))
		return (NULL);
	if (!init_philos(program))
		return (NULL);
	program->start_time = get_time_in_ms();
	return (program);
}
