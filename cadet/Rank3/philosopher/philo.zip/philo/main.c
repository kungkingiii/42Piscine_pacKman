/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bperez-a <bperez-a@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 10:07:28 by bperez-a          #+#    #+#             */
/*   Updated: 2024/03/27 12:16:56 by bperez-a         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	exit_program(t_program *program)
{
	int	i;

	i = 0;
	while (i < program->number_of_philosophers)
		pthread_mutex_destroy(&program->forks_mutexes[i++]);
	i = 0;
	while (i < program->number_of_philosophers)
		pthread_join(program->philosophers[i++].thread, NULL);
	pthread_mutex_destroy(&program->control_mutex);
	free(program->forks_mutexes);
	free(program->philosophers);
	free(program);
}

void	check_death(t_program *program)
{
	int				i;
	unsigned long	time_now;
	unsigned long	time_since_last_meal;

	i = 0;
	while (i < program->number_of_philosophers)
	{
		time_now = get_time_in_ms();
		pthread_mutex_lock(&program->control_mutex);
		time_since_last_meal = time_now
			- program->philosophers[i].last_meal_time;
		pthread_mutex_unlock(&program->control_mutex);
		if (time_since_last_meal >= (unsigned long)program->time_to_die)
		{
			log_action(&program->philosophers[i], "died");
			pthread_mutex_lock(&program->control_mutex);
			program->end_condition = 1;
			pthread_mutex_unlock(&program->control_mutex);
			break ;
		}
		i++;
	}
}

void	check_full(t_program *program)
{
	int	i;
	int	full;

	i = 0;
	full = 0;
	while (i < program->number_of_philosophers)
	{
		if (program->philosophers[i].full)
			full++;
		i++;
	}
	if (full == program->number_of_philosophers)
		program->end_condition = 1;
}

int	start_philosophers(t_program *program)
{
	int	i;

	i = 0;
	while (i < program->number_of_philosophers)
	{
		pthread_create(&program->philosophers[i].thread, NULL,
			philosopher_routine, &program->philosophers[i]);
		i++;
	}
	return (1);
}

int	main(int argc, char **argv)
{
	t_program	*program;

	if (argc < 5 || argc > 6)
	{
		printf("Incorrect number of arguments provided.\n");
		return (1);
	}
	program = init_program(argc, argv);
	if (!program)
	{
		printf("Incorrect arguments provided.\n");
		return (1);
	}
	if (!start_philosophers(program))
	{
		printf("Error running routine.\n");
		return (1);
	}
	while (!program->end_condition)
	{
		check_death(program);
		if (program->must_eat_count != -1)
			check_full(program);
	}
	exit_program(program);
}
